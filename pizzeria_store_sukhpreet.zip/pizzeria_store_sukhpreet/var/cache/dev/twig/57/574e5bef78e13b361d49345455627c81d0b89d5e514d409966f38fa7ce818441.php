<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* order/index.html.twig */
class __TwigTemplate_467cd8f6475fd529645c7e6621b13eba19f2d3fe6d6cf9934a21b03ba04b84ca extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "order/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "order/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "order/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Order Page!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        echo "    
    <!-- Main Container Start-->
    <div class=\"main-container\">
        <!-- Select Pizza Start-->
        <section class=\"select-pizza\">
            <h1>1. Bestellingen</h1>   
            <table>
                <thead>
                    <tr>
                        <th width=\"200\">Customer</th>
                        <th width=\"200\">Bodem</th>
                        <th width=\"200\">Topping</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    ";
        // line 22
        echo "                    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["orders"]) || array_key_exists("orders", $context) ? $context["orders"] : (function () { throw new RuntimeError('Variable "orders" does not exist.', 22, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["order"]) {
            // line 23
            echo "                        <tr>                 
                            <td>";
            // line 24
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["order"], "Customer", [], "any", false, false, false, 24), "customerName", [], "any", false, false, false, 24), "html", null, true);
            echo "</td>
                            <td>";
            // line 25
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["pizzeria"]) || array_key_exists("pizzeria", $context) ? $context["pizzeria"] : (function () { throw new RuntimeError('Variable "pizzeria" does not exist.', 25, $this->source); })()), twig_get_attribute($this->env, $this->source, $context["order"], "PizzeriaId", [], "any", false, false, false, 25), [], "array", false, false, false, 25), "html", null, true);
            echo "</td>
                            <td>";
            // line 26
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["topping"]) || array_key_exists("topping", $context) ? $context["topping"] : (function () { throw new RuntimeError('Variable "topping" does not exist.', 26, $this->source); })()), twig_get_attribute($this->env, $this->source, $context["order"], "ToppingId", [], "any", false, false, false, 26), [], "array", false, false, false, 26), "html", null, true);
            echo "</td>
                            <td><div class=\"form-group\">
                                    <form type=\"post\">
                                        <select id=\"pizzastatus_";
            // line 29
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["order"], "Id", [], "any", false, false, false, 29), "html", null, true);
            echo "\" title=\"status\">
                                            ";
            // line 30
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["orderStatus"]) || array_key_exists("orderStatus", $context) ? $context["orderStatus"] : (function () { throw new RuntimeError('Variable "orderStatus" does not exist.', 30, $this->source); })()));
            foreach ($context['_seq'] as $context["key"] => $context["status"]) {
                // line 31
                echo "                                                ";
                $context["selected"] = (((0 === twig_compare($context["key"], twig_get_attribute($this->env, $this->source, $context["order"], "OrderStatusId", [], "any", false, false, false, 31)))) ? ("selected") : (""));
                // line 32
                echo "                                                <option ";
                echo twig_escape_filter($this->env, (isset($context["selected"]) || array_key_exists("selected", $context) ? $context["selected"] : (function () { throw new RuntimeError('Variable "selected" does not exist.', 32, $this->source); })()), "html", null, true);
                echo " value=";
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo ">";
                echo twig_escape_filter($this->env, $context["status"], "html", null, true);
                echo "</option>
                                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['status'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 34
            echo "                                        </select>
                                        <button class =\"changestatus\" onClick=\"changeStatus(";
            // line 35
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["order"], "Id", [], "any", false, false, false, 35), "html", null, true);
            echo ")\"  type=\"button\">Wijzig status</button>
                                    </form></div>
                            </td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['order'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 40
        echo "                </tbody>
            </table>
        </section>
        <!-- Status Pizza Ends-->
    </div>
    <!-- Main Container Ends-->


    ";
        // line 49
        echo "    <script>
        function changeStatus(orderId) {
            var pizzastatus = \$(\"#pizzastatus_\" + orderId).val();
            \$.ajax({
                url: '/order/updatestatus',
                type: 'POST',
                dataType: 'json',
                async: true,
                data: {orderId: orderId, pizzastatus: pizzastatus},
                success: function (data, status) {
                    alert(data.message);
                },
                error: function (xhr, textStatus, errorThrown) {
                    alert('Ajax request failed.');
                }
            });
        }
    </script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "order/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  175 => 49,  165 => 40,  154 => 35,  151 => 34,  138 => 32,  135 => 31,  131 => 30,  127 => 29,  121 => 26,  117 => 25,  113 => 24,  110 => 23,  105 => 22,  78 => 5,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Order Page!{% endblock %}

{% block body %}    
    <!-- Main Container Start-->
    <div class=\"main-container\">
        <!-- Select Pizza Start-->
        <section class=\"select-pizza\">
            <h1>1. Bestellingen</h1>   
            <table>
                <thead>
                    <tr>
                        <th width=\"200\">Customer</th>
                        <th width=\"200\">Bodem</th>
                        <th width=\"200\">Topping</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    {# Order Display #}
                    {% for order in orders %}
                        <tr>                 
                            <td>{{order.Customer.customerName}}</td>
                            <td>{{pizzeria[order.PizzeriaId]}}</td>
                            <td>{{topping[order.ToppingId]}}</td>
                            <td><div class=\"form-group\">
                                    <form type=\"post\">
                                        <select id=\"pizzastatus_{{order.Id}}\" title=\"status\">
                                            {% for key, status in orderStatus %}
                                                {% set selected = (key == order.OrderStatusId) ? 'selected' : '' %}
                                                <option {{selected}} value={{key}}>{{status}}</option>
                                            {% endfor %}
                                        </select>
                                        <button class =\"changestatus\" onClick=\"changeStatus({{order.Id}})\"  type=\"button\">Wijzig status</button>
                                    </form></div>
                            </td>
                        </tr>
                    {% endfor %}
                </tbody>
            </table>
        </section>
        <!-- Status Pizza Ends-->
    </div>
    <!-- Main Container Ends-->


    {# Function to Update the Status #}
    <script>
        function changeStatus(orderId) {
            var pizzastatus = \$(\"#pizzastatus_\" + orderId).val();
            \$.ajax({
                url: '/order/updatestatus',
                type: 'POST',
                dataType: 'json',
                async: true,
                data: {orderId: orderId, pizzastatus: pizzastatus},
                success: function (data, status) {
                    alert(data.message);
                },
                error: function (xhr, textStatus, errorThrown) {
                    alert('Ajax request failed.');
                }
            });
        }
    </script>
{% endblock %}", "order/index.html.twig", "D:\\Projects\\pizzeria_store\\templates\\order\\index.html.twig");
    }
}
