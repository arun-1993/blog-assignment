<?php

namespace App\Services;

class CustomerSendEmailService implements NotificationInterface
{
    public function send(string $email, string $message): string
    {
        return sprintf('Email notification is sent on your Email ID '.$email.'. '.$message);
    }
}
