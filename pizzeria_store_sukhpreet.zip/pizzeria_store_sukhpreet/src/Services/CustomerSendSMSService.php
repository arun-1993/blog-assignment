<?php

namespace App\Services;

class CustomerSendSMSService implements NotificationInterface
{
    public function send(string $cellNumber, string $message): string
    {
        return sprintf('SMS notification is sent on your '.$cellNumber.', '.$message);
    }
}
