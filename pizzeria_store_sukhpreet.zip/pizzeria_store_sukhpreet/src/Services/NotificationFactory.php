<?php

namespace App\Services;

class NotificationFactory
{
    public function get(string $preferance): NotificationInterface
    {
        try {
            if ('email' === $preferance) {
                return new CustomerSendEmailService();
            } elseif ('sms' === $preferance) {
                return new CustomerSendSMSService();
            }
        }
        //catch exception
        catch (Exception $e) {
            echo 'Message: '.$e->getMessage();
        }
    }
}
