<?php

namespace App\Services;

interface NotificationInterface
{
    public function send(string $contactInformation, string $message);
}
