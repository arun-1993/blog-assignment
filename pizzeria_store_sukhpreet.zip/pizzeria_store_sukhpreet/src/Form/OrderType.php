<?php

namespace App\Form;

use App\Entity\Customer;
use App\Entity\Order;
use App\Enum\PizzeriaTypes;
use App\Enum\SoilTypes;
use App\Enum\ToppingTypes;
//Included the Customer Form
//Included the Entities
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
//Included the Sercie to fetch Param
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class OrderType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('customer', EntityType::class, [
                // Binded the Customer Entity
                'class' => Customer::class,
                'choice_label' => 'customer_name',
            ])
            ->add('pizzeria_id', ChoiceType::class, [
                'choices' => [
                    array_flip(PizzeriaTypes::getPizzeria()),
                ],
            ])
            ->add('soil_id', ChoiceType::class, [
                'choices' => [
                    array_flip(SoilTypes::getSoil()),
                ],
            ])
            ->add('topping_id', ChoiceType::class, [
                'choices' => array_flip(ToppingTypes::getTopping()),
            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Order::class,
        ]);
    }
}
