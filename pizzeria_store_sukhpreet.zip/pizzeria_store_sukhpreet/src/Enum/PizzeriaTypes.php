<?php

namespace App\Enum;

abstract class PizzeriaTypes
{
    const DOMINOS = 'Dominos';
    const NEW_YORK_PIZZA = 'New York Pizza';

    /**
     * @return array<string>
     */
    public static function getPizzeria()
    {
        return [
            1 => self::DOMINOS,
            2 => self::NEW_YORK_PIZZA,
        ];
    }
}
