<?php

namespace App\Enum;

abstract class ContactPreferenceTypes
{
    const EMAIL = 'email';
    const SMS = 'sms';

    /**
     * @return array<string>
     */
    public static function getContactPerference()
    {
        return [
            1 => self::EMAIL,
            2 => self::SMS,
        ];
    }

    /**
     * @return array<string>
     */
    public static function getContactPerferenceById($id)
    {
        if (1 === $id) {
            return self::SMS;
        } else {
            return self::EMAIL;
        }
    }
}
