<?php

namespace App\Enum;

abstract class ToppingTypes
{
    const HAWAII = 'Hawaii';
    const HOT_AND_SPICY = 'Hot & Spicy';

    /**
     * @return array<string>
     */
    public static function getTopping()
    {
        return [
            1 => self::HAWAII,
            2 => self::HOT_AND_SPICY,
        ];
    }
}
