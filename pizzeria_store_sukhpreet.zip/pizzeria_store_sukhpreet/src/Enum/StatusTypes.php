<?php

namespace App\Enum;

abstract class StatusTypes
{
    const BESTELLING_ONTVANGEN = 'Bestelling ontvangen';
    const PIZZA_VOORBEREID = 'Pizza voorbereid';
    const IN_DE_OVEN = 'In de oven';
    const BEZORGER_ONDERWEG = 'Bezorger onderweg';
    const AFGELEVERD = 'Afgeleverd';
    const PLUKKET_OPP = 'Plukket opp';

    /**
     * @return array<string>
     */
    public static function getStatus()
    {
        return [
            1 => self::BESTELLING_ONTVANGEN,
            2 => self::PIZZA_VOORBEREID,
            3 => self::IN_DE_OVEN,
            4 => self::BEZORGER_ONDERWEG,
            5 => self::AFGELEVERD,
            6 => self::PLUKKET_OPP,
        ];
    }
}
