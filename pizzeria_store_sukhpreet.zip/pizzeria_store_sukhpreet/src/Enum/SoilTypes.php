<?php

namespace App\Enum;

abstract class SoilTypes
{
    const CLASSIC = 'Classic';
    const CHEESY_CRUST = 'Cheesy Crust';

    /**
     * @return array<string>
     */
    public static function getSoil()
    {
        return [
            1 => self::CLASSIC,
            2 => self::CHEESY_CRUST,
        ];
    }
}
