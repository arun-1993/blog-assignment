<?php

namespace App\Controller;

use App\Entity\Customer;
use App\Entity\Order;
use App\Enum\ContactPreferenceTypes;
use App\Enum\PizzeriaTypes;
use App\Enum\StatusTypes;
/* Included the Order Form*/
/* Included the Entities*/
use App\Form\OrderType;
use App\Services\NotificationFactory;
use Doctrine\ORM\EntityManagerInterface;
/* Included the Services*/
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\DependencyInjection\ParameterBag\ParameterBagInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class CustomerController extends AbstractController
{
    /**
     * @Route("/customer", name="customer")
     */
    public function index(
        Request $request,
        EntityManagerInterface $entityManager,
        NotificationFactory $notificationFactory,
        ParameterBagInterface $params
    ): Response
    {
        $orderForm = $this->createForm(OrderType::class);
        /* Fetching the Enum Values params*/
        $pizzeriaType = PizzeriaTypes::getPizzeria();
        $orderForm->handleRequest($request);
        $orderObj = $entityManager->getRepository(Order::class);
        if ($orderForm->isSubmitted() && $orderForm->isValid()) {
            $order = $orderForm->getData();
            $preference = $order->getCustomer()->getNotificationPerferance();

            $mobile = $order->getCustomer()->getCustomerMobile();
            $email = $order->getCustomer()->getCustomerEmail();

            $notificationObj = $notificationFactory->get(ContactPreferenceTypes::getContactPerferenceById($preference));
            /* Business rules for the Delivery*/
            if ('Dominos' === $pizzeriaType[$order->getPizzeriaId()]) {
                $instruction = $params->get('dominos_delivery_instruction');
            } elseif ('New York Pizza' === $pizzeriaType[$order->getPizzeriaId()]) {
                $instruction = $params->get('new_york_pizza_delivery_instruction');
            }
            $contact = (1 === $preference) ? $mobile : $email;
            $message = $notificationObj->send($contact, $instruction);

            /* Order Saving */
            $orderObj->placeOrder($order);
            /* Sending the Flash Message */
            $this->addFlash('success', 'Order placed succesfully and '.$message);
            return $this->redirectToRoute('customer');
        }
        $data = [
            'form' => $orderForm->createView(), 'orders' => $orderObj->findAll(),
            'pizzeria' => $pizzeriaType, 'status' => StatusTypes::getStatus(),
        ];
        return $this->render('customer/index.html.twig', $data);
    }
}
