<?php

namespace App\Controller;

use App\Entity\Order;
use App\Enum\ContactPreferenceTypes;
use App\Enum\PizzeriaTypes;
use App\Enum\StatusTypes;
use App\Enum\ToppingTypes;
use App\Services\NotificationFactory;
/*Included Entities*/
use Doctrine\ORM\EntityManagerInterface;
/*Included Service for Notification and ConfigParam*/
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class OrderController extends AbstractController
{
    /**
     * @Route("/order", name="order")
     */
    public function index(EntityManagerInterface $entityManager): Response
    {
        return $this->render(
            'order/index.html.twig',
            ['controller_name' => 'OrderController',
                'orders' => $entityManager->getRepository(Order::class)->findAll(),
                'pizzeria' => PizzeriaTypes::getPizzeria(),
                'topping' => ToppingTypes::getTopping(),
                'orderStatus' => StatusTypes::getStatus(),
        ]
        );
    }

    /**
     * @Route("/order/updatestatus", name="updatestatus")
     */
    public function updateStatus(
        Request $request,
        EntityManagerInterface $entityManager,
        NotificationFactory $notificationFactory
    )
    {
        $postdata = $request->request->all();
        $order = $entityManager->getRepository(Order::class)->find($postdata['orderId']);

        $preference = $order->getCustomer()->getNotificationPerferance();
        $mobile = $order->getCustomer()->getCustomerMobile();
        $email = $order->getCustomer()->getCustomerEmail();

        $notificationObj = $notificationFactory->get(ContactPreferenceTypes::getContactPerferenceById($preference));

        /* Order Status Update */
        $order->setOrderStatusId($postdata['pizzastatus']);
        $order->setUpdatedAt(new \DateTime());
        $entityManager->persist($order);
        $entityManager->flush();

        $contact = (1 === $preference) ? $mobile : $email;
        $message = $notificationObj->send($contact, ' For the Order Status');
        return new JsonResponse(['result' => 'ok', 'message' => $message]);
    }
}
