<?php

namespace App\Entity;

use App\Repository\OrderRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=OrderRepository::class)
 * @ORM\Table(name="`order`")
 */
class Order
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity=Customer::class, inversedBy="orders_placed")
     * @ORM\JoinColumn(nullable=false)
     */
    private $customer;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    private $pizzeria_id;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    private $soil_id;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    private $topping_id;

    /**
     * @ORM\Column(type="integer")
     */
    private $order_status_id;

    /**
     * @ORM\Column(type="datetime")
     */
    private $created_at;

    /**
     * @ORM\Column(type="datetime")
     */
    private $updated_at;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getCustomer(): ?Customer
    {
        return $this->customer;
    }

    public function setCustomer(?Customer $customer): self
    {
        $this->customer = $customer;

        return $this;
    }

    public function getPizzeriaId(): ?int
    {
        return $this->pizzeria_id;
    }

    public function setPizzeriaId(?int $pizzeria_id): self
    {
        $this->pizzeria_id = $pizzeria_id;

        return $this;
    }

    public function getSoilId(): ?int
    {
        return $this->soil_id;
    }

    public function setSoilId(?int $soil_id): self
    {
        $this->soil_id = $soil_id;

        return $this;
    }

    public function getToppingId(): ?int
    {
        return $this->topping_id;
    }

    public function setToppingId(?int $topping_id): self
    {
        $this->topping_id = $topping_id;

        return $this;
    }

    public function getOrderStatusId(): ?int
    {
        return $this->order_status_id;
    }

    public function setOrderStatusId(int $order_status_id): self
    {
        $this->order_status_id = $order_status_id;

        return $this;
    }

    public function getCreatedAt(): ?\DateTimeInterface
    {
        return $this->created_at;
    }

    public function setCreatedAt(\DateTimeInterface $created_at): self
    {
        $this->created_at = $created_at;

        return $this;
    }

    public function getUpdatedAt(): ?\DateTimeInterface
    {
        return $this->updated_at;
    }

    public function setUpdatedAt(\DateTimeInterface $updated_at): self
    {
        $this->updated_at = $updated_at;

        return $this;
    }
}
