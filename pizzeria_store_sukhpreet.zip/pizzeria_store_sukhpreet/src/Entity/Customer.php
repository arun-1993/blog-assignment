<?php

namespace App\Entity;

use App\Repository\CustomerRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=CustomerRepository::class)
 */
class Customer
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $customer_name;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $customer_email;

    /**
     * @ORM\Column(type="integer")
     */
    private $customer_mobile;

    /**
     * @ORM\Column(type="smallint")
     */
    private $notification_perferance;

    /**
     * @ORM\Column(type="datetime")
     */
    private $created_at;

    /**
     * @ORM\Column(type="datetime")
     */
    private $updated_at;

    /**
     * @ORM\OneToMany(targetEntity=Order::class, mappedBy="customer", orphanRemoval=true)
     */
    private $orders_placed;

    public function __construct()
    {
        $this->orders_placed = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getCustomerName(): ?string
    {
        return $this->customer_name;
    }

    public function setCustomerName(string $customer_name): self
    {
        $this->customer_name = $customer_name;

        return $this;
    }

    public function getCustomerEmail(): ?string
    {
        return $this->customer_email;
    }

    public function setCustomerEmail(string $customer_email): self
    {
        $this->customer_email = $customer_email;

        return $this;
    }

    public function getCustomerMobile(): ?int
    {
        return $this->customer_mobile;
    }

    public function setCustomerMobile(int $customer_mobile): self
    {
        $this->customer_mobile = $customer_mobile;

        return $this;
    }

    public function getNotificationPerferance(): ?int
    {
        return $this->notification_perferance;
    }

    public function setNotificationPerferance(int $notification_perferance): self
    {
        $this->notification_perferance = $notification_perferance;

        return $this;
    }

    public function getCreatedAt(): ?\DateTimeInterface
    {
        return $this->created_at;
    }

    public function setCreatedAt(\DateTimeInterface $created_at): self
    {
        $this->created_at = $created_at;

        return $this;
    }

    public function getUpdatedAt(): ?\DateTimeInterface
    {
        return $this->updated_at;
    }

    public function setUpdatedAt(\DateTimeInterface $updated_at): self
    {
        $this->updated_at = $updated_at;

        return $this;
    }

    /**
     * @return Collection|Order[]
     */
    public function getOrdersPlaced(): Collection
    {
        return $this->orders_placed;
    }

    public function addOrdersPlaced(Order $ordersPlaced): self
    {
        if (!$this->orders_placed->contains($ordersPlaced)) {
            $this->orders_placed[] = $ordersPlaced;
            $ordersPlaced->setCustomer($this);
        }

        return $this;
    }

    public function removeOrdersPlaced(Order $ordersPlaced): self
    {
        if ($this->orders_placed->removeElement($ordersPlaced)) {
            // set the owning side to null (unless already changed)
            if ($ordersPlaced->getCustomer() === $this) {
                $ordersPlaced->setCustomer(null);
            }
        }

        return $this;
    }
}
